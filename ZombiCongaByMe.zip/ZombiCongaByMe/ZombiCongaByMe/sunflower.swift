//
//  sunflower.swift
//  ZombiCongaByMe
//
//  Created by priyanka khatta on 2018-06-15.
//  Copyright © 2018 priyanka khatta. All rights reserved.
//

import Foundation
import SpriteKit
class Sunflower: GameScene {

   
   override init(size: CGSize) {
        super.init(size: size)
    
    sunflowerR()
   
    
//    let snflwr = SKSpriteNode(imageNamed: "sunflower")
//    snflwr.name = "sunflower"
//    snflwr.position = CGPoint(
//        x: cameraRect.maxX + snflwr.size.width/2,
//        y: CGFloat.random(
//            min: cameraRect.minY + snflwr.size.height/2,
//            max: cameraRect.maxY - snflwr.size.height/2))
//
//    snflwr.zPosition = 50
//    addChild(snflwr)
//    let actionMove =
//        SKAction.moveBy(x: 0, y: -(size.height + snflwr.size.height), duration: 1.0)
//    let actionRemove = SKAction.removeFromParent()
//    snflwr.run(SKAction.sequence([actionMove, actionRemove]))
//
    
    }
    required init(coder aDecoder: NSCoder) {
        fatalError("init(coder:) has not been implemented")
    }
   // var gamevar = GameScene(size:CGSize(width: 2048, height: 1536))
    
   func sunflowerR() {
    
    run(SKAction.repeatForever(
        SKAction.sequence([SKAction.run() {
            [weak self] in self?.sunflowerRain()
            
            },SKAction.wait(forDuration: 1.0)])))

    
    }
    
    
}
