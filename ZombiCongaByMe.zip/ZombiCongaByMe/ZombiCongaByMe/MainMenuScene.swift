//
//  MainMenuScene.swift
//  ZombiCongaByMe
//
//  Created by priyanka khatta on 2018-06-14.
//  Copyright © 2018 priyanka khatta. All rights reserved.
//

import Foundation
import SpriteKit

class MainMenuScene: SKScene{
    let PlayButton = SKSpriteNode(imageNamed: "zombie4")
    let sunflower = SKSpriteNode(imageNamed: "sunflower")
    let oldLady = SKSpriteNode(imageNamed: "enemy")
    let smallFish = SKSpriteNode(imageNamed: "smallFish")
    let largeFish = SKSpriteNode(imageNamed: "bigFish")
    let settingB = SKSpriteNode(imageNamed: "setting")

    
    
    override func didMove(to view: SKView) {
        
        let background = SKSpriteNode(imageNamed: "MainMenu")
        background.position = CGPoint(x: size.width/2, y: size.height/2)
        background.zPosition = -1
        addChild(background)
       
        PlayButton.name = "PlayButton"
        PlayButton.isUserInteractionEnabled = false
        PlayButton.position = CGPoint(x: size.width * 0.1 , y: size.height * 0.8)
        PlayButton.zPosition = 10
        PlayButton.setScale(1.0)
        addChild(PlayButton)
        
        sunflower.name = "sunflower"
        sunflower.isUserInteractionEnabled = false
        sunflower.position = CGPoint(x: size.width * 0.1 , y: size.height * 0.55)
        sunflower.zPosition = 10
        sunflower.setScale(0.5)
        addChild(sunflower)
        
        oldLady.name = "oldLady"
        oldLady.isUserInteractionEnabled = false
        oldLady.position = CGPoint(x: size.width * 0.1 , y: size.height * 0.3)
        oldLady.zPosition = 10
        
        addChild(oldLady)
        
        smallFish.name = "smallFish"
        smallFish.isUserInteractionEnabled = false
        smallFish.position = CGPoint(x: size.width * 0.8 , y: size.height * 0.8)
        smallFish.zPosition = 10
        smallFish.setScale(0.5)
        addChild(smallFish)
        
        largeFish.name = "largeFish"
        largeFish.isUserInteractionEnabled = false
        largeFish.position = CGPoint(x: size.width * 0.8 , y: size.height * 0.55)
        largeFish.zPosition = 10
        largeFish.setScale(0.25)

        addChild(largeFish)
        
        
        settingB.name = "setting"
        settingB.isUserInteractionEnabled = false
        settingB.position = CGPoint(x: size.width * 0.8 , y: size.height * 0.3)
        settingB.zPosition = 10
        settingB.setScale(3.0)
        
        addChild(settingB)
    }
    
    override func touchesBegan(_ touches: Set<UITouch>,
                               with event: UIEvent?) {
        
        let touch = touches.first!
      
        if PlayButton.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                
                scene.scaleMode = SKSceneScaleMode.aspectFill
                view.presentScene(scene, transition: transition)
            }
        }
        if sunflower.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                scene.obj = 1
                scene.scaleMode = SKSceneScaleMode.aspectFill
                
                view.presentScene(scene, transition: transition)
            }
        }
        if oldLady.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                scene.obj = 2
                scene.scaleMode = SKSceneScaleMode.aspectFill
                view.presentScene(scene, transition: transition)
            }
        }
        if smallFish.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                scene.obj = 3
                scene.scaleMode = SKSceneScaleMode.aspectFill
                view.presentScene(scene, transition: transition)
            }
        }
        if largeFish.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                scene.obj = 4
                scene.scaleMode = SKSceneScaleMode.aspectFill
                view.presentScene(scene, transition: transition)
            }
        }
        if settingB.contains(touch.location(in: self)) {
            if let view = view {
                let scene = GameScene (size: size)
                let transition:SKTransition = SKTransition.fade(withDuration: 0.5)
                scene.obj = 5
                scene.scaleMode = SKSceneScaleMode.aspectFill
                view.presentScene(scene, transition: transition)
            }
        }
    }

}

